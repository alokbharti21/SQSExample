package com.aws.sqs.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.amazonaws.services.sqs.model.SendMessageResult;
import com.aws.sqs.client.AwsSqsDemoClient;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AwsDemoMessagePublisherService {
	
	private int i = 0;
	
	@Autowired
	private AwsSqsDemoClient basicSqsClient;
	
	@Scheduled(fixedRate = 1000)
	private void sendmessage() {
		SendMessageResult result = basicSqsClient.getBasicSqsClient().sendMessage(basicSqsClient.getAWSSqsUrl(), "Hello" + i);
		log.info("Published Message {}", result.getMessageId());
		i++;
	}
	

}
